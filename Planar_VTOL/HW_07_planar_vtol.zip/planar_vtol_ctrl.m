% %-------------------------HW_06 (PID)---------------------- 
% function Tau=planar_vtol_ctrl(in,Pa)
%     h_r   = in(1);
%     h     = in(2);
%     z_r   = in(3);
%     z     = in(4);
%     theta = in(5);
%     t     = in(6);
%     
%     % set persistent flag to initialize integrators and 
%     % differentiators at the start of the simulation
%     persistent flag
%     if t<Pa.Ts
%         flag = 1;
%     else
%         flag = 0;
%     end
%     
%     F = PID_h(h_r,h,flag,Pa.kp_h,Pa.ki_h,Pa.kd_h,...
%                     Pa.F_max,Pa.Ts,Pa.sigma);
%     theta_r = PID_z(z_r,z,flag,Pa.kp_z,Pa.ki_z,Pa.kd_z,...
%                     Pa.Ts,Pa.sigma);
%     Tau     = PD_th(theta_r,theta,flag,Pa.kp_th,Pa.kd_th,...
%                     Pa.Ts,Pa.sigma,F);
%     
% end
% 
% %------------------------------------------------------------
% % PID control for longitudinal position
% function u = PID_h(h_c,h,flag,kp,ki,kd,limit,Ts,sigma)
%     % declare persistent variables
%     persistent integrator
%     persistent hdot
%     persistent error_d1
%     persistent h_dl
%     % reset persistent variables at start of simulation
%     if flag==1
%         integrator  = 0;
%         hdot    = 0;
%         error_d1    = 0;
%         h_dl    = h;
%     end
%     
%     % compute the error
%     error = h_c-h;
%     % update derivative of h
%     hdot = (2*sigma-Ts)/(2*sigma+Ts)*hdot...
%            + 2/(2*sigma+Ts)*(h-h_dl);
%     % update integral of error
%     if abs(hdot)<.001
%         integrator = integrator + (Ts/2)*(error+error_d1);
%     end
%     % update delayed variables for next time through the loop
%     error_d1 = error;
%     h_dl     = h;
% 
%     % compute the pid control signal
%     u_unsat = kp*error + ki*integrator - kd*hdot;
%     u = sat(u_unsat,limit);
%     
%     % integrator anti-windup
% %     if ki~=0
% %         integrator = integrator + Ts/ki*(u-u_unsat);
% %     end
% end
% 
% %------------------------------------------------------------
% % PID control for longitudinal position
% function u = PID_z(z_c,z,flag,kp,ki,kd,Ts,sigma)
%     % declare persistent variables
%     persistent integrator
%     persistent zdot
%     persistent error_d1
%     persistent z_dl
%     % reset persistent variables at start of simulation
%     if flag==1
%         integrator  = 0;
%         zdot    = 0;
%         error_d1    = 0;
%         z_dl    = z;
%     end
%     
%     % compute the error
%     error = z_c-z;
%     % update derivative of h
%     zdot = (2*sigma-Ts)/(2*sigma+Ts)*zdot...
%            + 2/(2*sigma+Ts)*(z-z_dl);
%     % update integral of error
%     if abs(zdot)<.001
%         integrator = integrator + (Ts/2)*(error+error_d1);
%     end
%     % update delayed variables for next time through the loop
%     error_d1 = error;
%     z_dl     = z;
% 
%     % compute the pid control signal
%     u = kp*error + ki*integrator - kd*zdot;
% %     u = sat(u_unsat,limit);
%     
% %     % integrator anti-windup
% %     if ki~=0
% %         integrator = integrator + Ts/ki*(u-u_unsat);
% %     end
% end
% 
% %------------------------------------------------------------
% % PID control for angle theta
% function u = PD_th(theta_c,theta,flag,kp,kd,Ts,sigma,F)
%     % declare persistent variables
%     persistent thetadot
%     persistent theta_d1
%     % reset persistent variables at start of simulation
%     if flag==1
%         thetadot    = 0;
%         theta_d1    = 0;
%     end
%     
%     % compute the error
%     error = theta_c-theta;
%     % update derivative of y
%     thetadot = (2*sigma-Ts)/(2*sigma+Ts)*thetadot...
%                + 2/(2*sigma+Ts)*(theta-theta_d1);
%     % update delayed variables for next time through the loop
% 
%     theta_d1 = theta;
% 
%     % compute the pid control signal
%     u_unsat = kp*error - kd*thetadot;
%     u = [F; u_unsat];
% %     u = sat(u_unsat,limit);
%     
% end
% 
% 
% %-----------------------------------------------------------------
% % saturation function
% function out = sat(in,limit)
%     if     in > limit,      out = limit;
%     elseif in < -limit,     out = -limit;
%     else                    out = in;
%     end
% end

%-----------------------HW_07 (State Feedback)--------------------------
function Tau=planar_vtol_ctrl(in,Pa)
    h_r   = in(1);
    h     = in(2);
    z_r   = in(3);
    z     = in(4);
    theta = in(5);
    t     = in(6);
    
    persistent zdot
    persistent z_dl
    persistent thetadot
    persistent theta_dl

    if t<Pa.Ts
        zdot = 0;
        z_dl = z;
        thetadot = 0;
        theta_dl = theta;
    end
    
    % dirty derivative
    zdot = Pa.beta*zdot...
        + (1-Pa.beta)*(z-z_dl)/Pa.Ts;
    thetadot = Pa.beta*thetadot...
        + (1-Pa.beta)*(theta-theta_dl)/Pa.Ts;
    z_dl = z;
    theta_dl = theta;
    
    % integrator (with integrator)
    error = z_r - z;
    persistent integrator
    persistent error_d1
    % reset persistent variables at t=0
    if t<Pa.Ts
        integrator  = 0;
        error_d1    = 0;
    end
    integrator = integrator...
        + (Pa.Ts/2)*(error+error_d1);
    error_d1 = error;
    
    % construct the state
    x = [z; theta; zdot; thetadot];
    
    % compute the state feedback controller
%     Tau_unsat = -Pa.K_z*x+Pa.kr_z*z_r;  % without integrator
    Tau_unsat = -Pa.K_z*x+Pa.ki_z*integrator;  % with integrator
    
%     F = state_FB(h_r, h, Pa.F_max, Pa.K_h, Pa.kr_h, t, Pa.Ts, Pa.beta); % without integrator
    F = state_FB(h_r, h, Pa.F_max, Pa.K_h, Pa.ki_h, t, Pa.Ts, Pa.beta); % with integrator
    Tau = [F, Tau_unsat];
end

% function u=state_FB(h_r, h, limit, K, kr, t, ts, beta) % without integrator
%     persistent hdot
%     persistent h_dl
%     
%     if t<ts
%         hdot = 0;
%         h_dl = h;
%     end
%     % dirty derivative
%     hdot = beta*hdot...
%         + (1-beta)*(h-h_dl)/ts;
%     h_dl = h;
%     
%     x = [h; hdot];
%     u = sat(-K*x+kr*h_r, limit);
% end

function u=state_FB(h_r, h, limit, K, ki, t, ts, beta) % with integrator
    persistent hdot
    persistent h_dl
    
    if t<ts
        hdot = 0;
        h_dl = h;
    end
    % dirty derivative
    hdot = beta*hdot...
        + (1-beta)*(h-h_dl)/ts;
    h_dl = h;
    
    % integrator (with integrator)
    error = h_r - h;
    persistent integrator
    persistent error_d1
    % reset persistent variables at t=0
    if t<ts==1,
        integrator  = 0;
        error_d1    = 0;
    end
    integrator = integrator...
        + (ts/2)*(error+error_d1);
    error_d1 = error;
    
    x = [h; hdot];
    u_unsat = -K*x - ki*integrator;
    u = sat(u_unsat, limit);
end

% saturation function
function out = sat(in,limit)
    if     in > limit,      out = limit;
    elseif in < -limit,     out = -limit;
    else                    out = in;
    end
end

