% parameters for animation
Pa.mc = 1;
Pa.Jc = 0.0042;
Pa.mw = 0.25;
Pa.d = 0.3;
Pa.mu = 0.1;
Pa.g = 9.81;

% Initial Conditions
Pa.z0 = 0.0;                % initial mass position
Pa.h0 = 0.0;
Pa.theta0 = 0.0;             %initial theta position of beam, m
Pa.zdot0 = 0.0;             % initial mass velocity, m/s
Pa.hdot0 = 0.0;
Pa.thetadot0 = 0.0;          %inittial angular velocity of beam, rad/s

% Simulation Parameters
Pa.t_start = 0.0;  % Start time of simulation
Pa.t_end = 100.0;   % End time of simulation
Pa.Ts = 0.01;      % sample time for simulation
Pa.t_plot = 0.5;   % the plotting and animation is updated at this rate

% dirty derivative parameters
Pa.sigma = 0.05; % cutoff freq for dirty derivative
Pa.beta = (2*Pa.sigma-Pa.Ts)/(2*Pa.sigma+Pa.Ts); % dirty derivative gain

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       PD Control: Time Design Strategy
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% saturation limits
Pa.F_max = 15;                   % Max Force, N
% error_max = 1;        		   % Max step size,m
% Pa.theta_max = 30.0*pi/180.0;  % Max theta, rads

M = 10;

% Tuning Parameters
t_r_h = 0.6;  % 1 for HW_06 
zeta_h = 0.7;
tr_th = 0.25;  % 0.9 for HW_06 
zeta_th = 0.7;
tr_z = 1.2;  % M*tr_th for HW_06
zeta_z = 0.7;
integrator_pole_z = 0.3;
integrator_pole_h = -1;

%--------------------------------------------------
%               Longitudinal Control (HW_06)
%--------------------------------------------------
wn_h = 2.2/t_r_h;
Pa.kp_h = wn_h^2*(Pa.mc+2*Pa.mw);
Pa.kd_h = 2*zeta_h*wn_h*(Pa.mc+2*Pa.mw);
Pa.ki_h = 2;

%---------------------------------------------------
%                    Inner Loop (HW_06)
%---------------------------------------------------
% gains for inner loop
wn_th    = 2.2/tr_th; % natural frequency for inner loop
Pa.kp_th  = (2*Pa.d^2*Pa.mw+Pa.Jc)*wn_th^2; % kp - inner loop
Pa.kd_th  = (2*Pa.d^2*Pa.mw+Pa.Jc)*2*zeta_th*wn_th; % kd - inner loop
% DC gain for inner loop
k_DC_gain = 1;

%---------------------------------------------------
%                    Outer Loop (HW_06)
%---------------------------------------------------

%PD design for outer loop
wn_z = 2.2/tr_z; % natural frequency for outer loop
Pa.kp_z = -wn_z^2/Pa.g;
Pa.kd_z = (Pa.mu-(2*zeta_z*wn_z*(Pa.mc+2*Pa.mw)))/((Pa.mc+2*Pa.mw)*Pa.g);
Pa.ki_z = -0.0001;

%------------------------HW_07--------------------------
%----------------Longitudinal----------------- 
a0 = Pa.mc+2*Pa.mw;
A_h = [0 1;
       0 0];
B_h = [0; 1/a0];
C_h = [1 0];

% % gain calculation (without integrator)
% des_char_poly_h = [1, 2*zeta_h*wn_h, wn_h^2];
% des_poles_h = roots(des_char_poly_h);

% gain calculation (with integrator)
des_char_poly_h = conv([1, 2*zeta_h*wn_h, wn_h^2],...
                       poly(integrator_pole_h));
des_poles_h = roots(des_char_poly_h);

% form augmented system
A1 = [A_h, zeros(2,1);
      -C_h, 0];
B1 = [B_h; 0];

% % Compute gains if system is controllable (without integrator)
% if rank(ctrb(A_h,B_h)) ~= 2
%     disp('The system is not controllable')
% else
%     Pa.K_h = place(A_h, B_h, des_poles_h);
%     Pa.kr_h = -1.0/(C_h*inv(A_h-B_h*Pa.K_h)*B_h);
% end

% Compute gains if system is controllable (with integrator)
if rank(ctrb(A1,B1)) ~= 3
    disp('The system is not controllable')
else
    K1 = place(A1, B1, des_poles_h);
    Pa.K_h = K1(1:2);
    Pa.ki_h = K1(3);
end

%------------------Lateral---------------
b0 = 2*Pa.d^2*Pa.mw + Pa.Jc;
A_z = [0 0 1 0;
       0 0 0 1;
       0 -Pa.g -Pa.mu/a0 0;
       0 0 0 0];
B_z = [0; 0; 0; 1/b0];
C_z = [1 0 0 0;
       0 1 0 0];

% % gain calculation (without integrator)
% des_char_poly_z = conv([1, 2*zeta_z*wn_z, wn_z^2],...
%                        [1, 2*zeta_th*wn_th, wn_th^2]);
% des_poles_z = roots(des_char_poly_z);

% gain calculation (with an integrator)
des_char_poly_z = conv(...
                conv([1, 2*zeta_z*wn_z, wn_z^2],...
                [1, 2*zeta_th*wn_th, wn_th^2]),...
                poly(integrator_pole_z));
des_poles_z = roots(des_char_poly_z);

% form augmented system
C_zr = [1,0,0,0];
A2 = [A_z, zeros(4,1);
      -C_zr, 0];
B2 = [B_z; 0];

% % Compute gains if system is controllable (without integrator)
% if rank(ctrb(A_z,B_z)) ~= 4
%     disp('The system is not controllable')
% else
%     Pa.K_z = place(A_z, B_z, des_poles_z);
%     Pa.kr_z = -1.0/(C_zr*inv(A_z-B_z*Pa.K_z)*B_z);
% end

% Compute gains if system is controllable (with integrator)
if rank(ctrb(A2,B2)) ~= 5
    disp('The system is not controllable')
else
    K2 = place(A2, B2, des_poles_z);
    Pa.K_z = K2(1:4);
    Pa.ki_z = K2(5);
end



